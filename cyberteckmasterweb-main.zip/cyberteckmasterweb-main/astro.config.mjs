// @ts-check
import { defineConfig } from 'astro/config';
import mdx from '@astrojs/mdx';
import sitemap from '@astrojs/sitemap';
import cloudflare from '@astrojs/cloudflare';
import robotsTxt from 'astro-robots-txt';
import { SITE_URL } from './src/consts';

// https://astro.build/config
export default defineConfig({
  site: SITE_URL || 'https://cyberteckmaster.com',
  output: 'server', // Enable SSR for Cloudflare
  adapter: cloudflare({
    mode: 'advanced', // Full Workers control
    platformProxy: {
      enabled: true, // Enable local dev proxy
    },
  }),
  integrations: [
    mdx({
      syntaxHighlight: 'shiki', // Use Shiki for code highlighting
      shikiConfig: {
        theme: 'github-dark', // Tech-friendly theme
      },
    }),
    sitemap({
      changefreq: 'weekly',
      priority: 0.7,
      lastmod: new Date('2025-05-22T14:25:00+05:30'), // Current IST
      filter: (page) => !page.includes('/draft/'), // Exclude draft posts
    }),
    robotsTxt({
      sitemap: true, // Include sitemap in robots.txt
      policy: [
        {
          userAgent: '*',
          allow: '/',
          disallow: ['/admin/', '/draft/'],
          crawlDelay: 10,
        },
      ],
    }),
  ],
  vite: {
    css: {
      preprocessorOptions: {
        scss: {}, // Enable SCSS if needed
      },
    },
    build: {
      cssMinify: true, // Minify CSS for production
      rollupOptions: {
        output: {
          assetFileNames: 'assets/[name].[hash][extname]', // Optimize asset naming
        },
      },
    },
    optimizeDeps: {
      exclude: ['@astrojs/cloudflare'], // Prevent Vite issues with Cloudflare
    },
  },
  markdown: {
    shikiConfig: {
      theme: 'github-dark',
      wrap: true, // Wrap long code lines
    },
  },
  redirects: {
    '/blog/:id': '/blog/:slug', // Legacy ID to slug redirects
  },
  server: {
    port: 3000, // Consistent dev port
  },
});