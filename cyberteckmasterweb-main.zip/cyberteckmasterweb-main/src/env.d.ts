/// <reference types="astro/client" />

// Import Cloudflare runtime from @astrojs/cloudflare
type Runtime = import("@astrojs/cloudflare").Runtime<Env>;

// Define Cloudflare environment variables
interface Env {
  // Example: Cloudflare KV for analytics or caching
  ANALYTICS_KV?: KVNamespace;
  // Example: API key for external services (e.g., Mailchimp)
  MAILCHIMP_API_KEY?: string;
  // Add other environment variables as needed
  [key: string]: any;
}

// Extend Astro's App.Locals with Cloudflare runtime and custom locals
declare namespace App {
  interface Locals extends Runtime {
    // Runtime environment (Cloudflare-specific)
    env: Env;
    // Custom locals for Cyberteckmaster
    site: {
      title: string;
      description: string;
      url: string;
    };
    // Analytics tracking (e.g., for rss.xml.js)
    trackEvent?: (event: string, data: Record<string, string>) => Promise<void>;
    // User session or context (optional, for future use)
    user?: {
      id?: string;
      email?: string;
    };
  }
}