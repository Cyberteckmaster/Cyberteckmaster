import { getCollection } from 'astro:content';

export async function GET(context) {
  const posts = await getCollection('blog');
  const publishedPosts = posts
    .filter((post) => post.data.pubDate && !post.data.draft)
    .sort((a, b) => new Date(b.data.pubDate) - new Date(a.data.pubDate));

  return new Response(
    JSON.stringify({
      version: 'https://jsonfeed.org/version/1.1',
      title: 'Cyberteckmaster: Tech Insights & Solutions',
      home_page_url: 'https://cyberteckmaster.com',
      feed_url: 'https://cyberteckmaster.com/rss.json',
      description: 'Expert tutorials, AI insights, cybersecurity guides, and IT solutions.',
      items: publishedPosts.map((post) => ({
        id: `https://cyberteckmaster.com/blog/${post.slug}`,
        url: `https://cyberteckmaster.com/blog/${post.slug}`,
        title: post.data.title || 'Untitled Post',
        content_html: post.body || post.data.description,
        date_published: post.data.pubDate ? new Date(post.data.pubDate).toISOString() : new Date().toISOString(),
        author: { name: post.data.author?.name || 'Cyberteckmaster Team' },
        tags: post.data.tags || ['Technology', 'Cybersecurity', 'AI'],
        image: post.data.heroImage || undefined,
      })),
    }),
    { headers: { 'Content-Type': 'application/feed+json' } }
  );
}
