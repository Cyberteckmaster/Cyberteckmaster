import rss from "@astrojs/rss";
import { getCollection } from "astro:content";
import { SITE_TITLE, SITE_DESCRIPTION } from "../consts";
import sanitizeHtml from "sanitize-html";

// Utility to detect MIME type (simplified for WebP, extendable for other formats)
const getImageMimeType = (url) => {
  // Extend with actual MIME detection (e.g., file-type) for production
  return url.endsWith(".webp") ? "image/webp" : "image/jpeg";
};

export async function GET(context) {
  // Fetch all blog posts
  const posts = await getCollection("blog");

  // Filter published posts and sort by pubDate (newest first)
  const publishedPosts = posts
    .filter((post) => post.data.pubDate && !post.data.draft)
    .sort((a, b) => new Date(b.data.pubDate) - new Date(a.data.pubDate));

  // Dynamic last build date (current time: May 22, 2025, 14:03 IST)
  const lastBuildDate = new Date();

  return rss({
    // Feed metadata
    title: SITE_TITLE || "Cyberteckmaster: Tech Insights & Solutions",
    description: SITE_DESCRIPTION || "Expert tutorials, AI insights, cybersecurity guides, and IT solutions from Cyberteckmaster.",
    site: context.site || "https://cyberteckmaster.com",
    items: publishedPosts.map((post) => {
      // Validate and sanitize fields
      const title = post.data.title || "Untitled Post";
      const description = post.data.description || "Discover the latest tech insights from Cyberteckmaster.";
      const pubDate = post.data.pubDate ? new Date(post.data.pubDate) : lastBuildDate;
      const slug = post.slug || post.id;

      // Warn about missing content in development
      if (!post.body && import.meta.env.DEV) {
        console.warn(`Missing body content for post: ${slug}`);
      }

      const content = post.body
        ? sanitizeHtml(post.body, {
            allowedTags: ["p", "strong", "em", "a", "ul", "li", "h2", "h3"],
            allowedAttributes: { a: ["href"] },
          })
        : description;

      // Enhanced author field with per-post override
      const author = post.data.author?.name && post.data.author?.email
        ? `${post.data.author.name} <${post.data.author.email}>`
        : "Cyberteckmaster Team <editor@cyberteckmaster.com>";

      return {
        title,
        description,
        pubDate,
        link: `/blog/${slug}/`,
        author,
        categories: post.data.categories || ["Technology", "Cybersecurity", "AI"],
        guid: `https://cyberteckmaster.com/blog/${slug}`,
        content, // Used for content:encoded
        enclosure: post.data.heroImage
          ? {
              url: post.data.heroImage.startsWith("http")
                ? post.data.heroImage
                : `${context.site}${post.data.heroImage}`,
              type: getImageMimeType(post.data.heroImage),
              length: 0, // TODO: Add actual file size via fetch in production
            }
          : undefined,
        customData: `<content:encoded><![CDATA[${content}]]></content:encoded>
                     <social:twitter>New post: ${title} 🚀 #Tech #Cybersecurity ${context.site}/blog/${slug}</social:twitter>
                     <analytics:track>post-view:${slug}</analytics:track>`,
      };
    }),
    // Additional feed metadata
    customData: `<language>en-us</language>
                 <managingEditor>editor@cyberteckmaster.com</managingEditor>
                 <webMaster>webmaster@cyberteckmaster.com</webMaster>
                 <lastBuildDate>${lastBuildDate.toUTCString()}</lastBuildDate>
                 <atom:link href="https://cyberteckmaster.com/rss.xml" rel="self" type="application/rss+xml" />
                 <generator>Cyberteckmaster RSS v1.2</generator>
                 <ttl>1440</ttl>`,
    trailingSlash: false,
    stylesheet: "/rss-styles.xsl",
  });
}