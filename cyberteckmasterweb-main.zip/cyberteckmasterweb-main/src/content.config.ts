import { glob } from "astro/loaders";
import { defineCollection, z } from "astro:content";
import { DEFAULT_CATEGORIES } from "../consts";

// Blog collection schema
const blog = defineCollection({
  loader: glob({
    base: "./src/content/blog",
    pattern: "**/*.{md,mdx}",
  }),
  schema: z.object({
    // Required fields
    title: z.string().min(1, "Title is required").max(100, "Title must be 100 characters or less"),
    description: z.string().min(1, "Description is required").max(160, "Description must be 160 characters or less"),
    pubDate: z.coerce.date().refine((date) => date <= new Date(), {
      message: "pubDate cannot be in the future",
    }),
    slug: z.string().regex(/^[a-z0-9-]+$/i, "Slug must be alphanumeric with hyphens").optional(),
    
    // Optional fields
    updatedDate: z.coerce.date().optional(),
    heroImage: z.string().url().or(z.string().startsWith("/")).optional(),
    author: z
      .object({
        name: z.string().min(1, "Author name is required"),
        email: z.string().email("Invalid email format").optional(),
      })
      .optional(),
    tags: z.array(z.string()).default(DEFAULT_CATEGORIES),
    draft: z.boolean().default(false),
    keywords: z.array(z.string()).optional(),
  }),
});

// Define collections
export const collections = {
  blog,
};