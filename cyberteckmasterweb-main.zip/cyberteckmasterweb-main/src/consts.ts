// src/consts.ts
// Global data for Cyberteckmaster.com, accessible via `import` across the Astro site.

// Site metadata
export const SITE_TITLE: string = "Cyberteckmaster: Tech Insights & Solutions";
export const SITE_DESCRIPTION: string =
  "Discover expert tutorials, AI insights, cybersecurity guides, and IT solutions at Cyberteckmaster. Curated for tech professionals, students, and enthusiasts.";

// Base URLs
export const SITE_URL: string = "https://cyberteckmaster.com";
export const RSS_URL: string = `${SITE_URL}/rss.xml`;
export const JSON_FEED_URL: string = `${SITE_URL}/rss.json`;

// Social media and contact
export const SOCIAL_LINKS: Record<string, string> = {
  twitter: "https://twitter.com/cyberteckmaster",
  linkedin: "https://linkedin.com/company/cyberteckmaster",
  github: "https://github.com/cyberteckmaster",
};
export const CONTACT_EMAIL: string = "editor@cyberteckmaster.com";

// Content settings
export const DEFAULT_HERO_IMAGE: string = "/images/default-hero.webp";
export const POSTS_PER_PAGE: number = 10;
export const DEFAULT_CATEGORIES: string[] = ["Technology", "Cybersecurity", "AI"];

// Analytics (placeholder for tracking IDs)
export const GOOGLE_ANALYTICS_ID: string | null = null; // e.g., "G-XXXX"

// Date for last build (updated dynamically in rss.xml.js, fallback here)
export const LAST_BUILD_DATE: string = new Date("2025-05-22T14:18:00+05:30").toUTCString();